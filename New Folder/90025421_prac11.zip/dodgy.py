from accounts import BankAccount

def undefinedFun():
    print("This is undefined fun!")

cat = dog

if cat:
    print(bird)

print("The never ending string)   

undefinedFunction()

for badtabs in range(10):
    firstline = 5
    secondline = 10 
    if badtabs > 4:
	secondline = 10 
    print("Output = ", firstline, " + ", secondline)

